#bin/bash
#Using your findings from the player analysis, create a seperate script to look at each day
#and time that you determined losses occurred. Use awk, pipes and grep to isolate out the following feilds
#Time, AM/PM, First name and last name of roulette dealer. 
#For example, if a loss occurred on March 10 at 2pm, you would write one script to find the roulette dealer who was working at that specific day and 

#Type the time and date 

grep $1":"$2":"$3" "$4 $5_Dealer_schedule | awk '{print $1" "$2"   "$5" "$6}' >>Dealers_working_during_losses 
