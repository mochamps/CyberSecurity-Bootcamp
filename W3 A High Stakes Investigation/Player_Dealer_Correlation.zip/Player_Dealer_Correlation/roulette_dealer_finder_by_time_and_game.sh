#bin/bash
if [[ $1 = Blackjack ]];
      	then 
	grep $2":"$3":"$4" "$5 $6_Dealer_schedule|awk '{print $1" "$2"  "$3" "$4}' 
	echo "This was the indvidual dealing Blackjack" 
elif [[ $1 = Roulette ]];
        then
        grep $2":"$3":"$4" "$5 $6_Dealer_schedule|awk '{print $1" "$2"  "$5" "$6}'
	echo "This was the dealing Russian Roulette"
elif [[ $1 = TexasHE ]];
        then 
        grep $2":"$3":"$4" "$5 $6_Dealer_schedule|awk '{print $1" "$2"  "$7" "$8}'
	 echo "This was the indvidual dealing Texas Holde Em"
fi


